import { Component } from "react";
import ChildComp from "./child";

class App extends Component{
    render(){
        return <div>
                    <ChildComp/>
                </div>
        
    }
}

export default App;