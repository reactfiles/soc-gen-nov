import React, { Component } from "react";

class ChildComp extends Component{
    state = {
        power : 0
    }
   /*  
   constructor(){
        super();
    } 
    */
   ipref = React.createRef();
    render(){
        return <div>
                    <h1>Events</h1>
                    <h2>Power : {this.state.power}</h2>
                    <button onClick={ this.addPower }>Increase Power</button>
                    <button onClick={ () => this.reducePower() }>Decrease Power</button>
                    <button onClick={ () => this.setPower() }>Set Power to 10</button>
                    <input onChange={ this.powerRanger } type="range" />
                    <br />
                    <br />
                    <input ref={this.ipref} type="number" />
                    <button onClick={ this.powerNumber }>Set Power from Number</button>
               </div>
    }
    addPower = () => {
        this.setState({ power : this.state.power + 1 })
    }
    reducePower(){
        this.setState({ power : this.state.power - 1 })
    }
    setPower(){
        this.setState({ power : 10 })
    }
    powerRanger = (event) => {
        this.setState({ power : Number(event.target.value) })
    }
    powerNumber = () => {
        this.setState({ power : Number(this.ipref.current.value) })
    }
}

export default ChildComp;