import React, { Component } from "react";
import ChildComp from "./child";

class App extends Component{
    state = {
        appmessage : "Message from App Component"
    }
    ipref = React.createRef();
    render(){
        return <div>
                    <input ref={this.ipref} type="text" />
                    <button onClick={this.changeHandler}>Change Message</button>
                    <hr />
                    <ChildComp message={this.state.appmessage }/>
                </div>
    }
    changeHandler = () =>{
        this.setState({
            appmessage : this.ipref.current.value
        })
    }
}

export default App;