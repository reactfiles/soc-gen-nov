import React, { Component } from "react";
import "./styles/childstyle.css";

class ChildComp extends Component{
    state = {
        message : "welcome to your life"
    }
    render(){
        /* return <div style={ { backgroundColor : "darkslategray", color : "whitesmoke", fontFamily: "sans-serif", padding : "10px" }  }> */
        return <div className="box">
                    <h1>Component Communication</h1>
                    <h2>{ this.state.message }</h2>
                    <input onChange={(evt)=> this.setState({ message : evt.target.value })} type="text" />
                    <h2>Parent's Message : { this.props.message }</h2>
               </div>
    }

}

export default ChildComp;