import ReactDOM from "react-dom/client";
import ClassApp from "./classapp";

ReactDOM.createRoot(document.getElementById("root")).render(<ClassApp/>)