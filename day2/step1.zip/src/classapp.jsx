import React, { Component } from "react";

class ClassApp extends Component{
    state = {
        avengers : ['Ironman'],
        title : "My Avenger's App"
    }
    ipref = React.createRef();
    render(){
        return  <>
                    <h1 className="box">Class Component</h1>
                    <h2>{ this.state.title }</h2>
                    <h3>Number of Avengers : {this.state.avengers.length }</h3>
                    <button onClick={()=> this.setState({ title : "Title is updated" })}>Change Title</button>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    <label htmlFor="avenger">Enter a Name : </label>
                    <input ref={this.ipref} id="avenger"/>
                    <button onClick={this.clickHandler}>Add Avenger</button>
                    <hr/>
                    <ol>{this.state.avengers.map((val, idx) => <li key={idx}>{ val }</li> )}</ol>
                </>
    }
    clickHandler = () => {
        this.setState({
            avengers : [...this.state.avengers, this.ipref.current.value ]
        })
    }
} 


export default ClassApp;