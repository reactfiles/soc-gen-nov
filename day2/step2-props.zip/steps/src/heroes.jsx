import { Component } from "react";

class Heroes extends Component{
    render(){
        return <div>
            <h1></h1>
            <ol>
                <li>Waiting</li>
            </ol>
        </div>
    }
}

export default Heroes;