import { useDispatch, useSelector } from "react-redux"
import {addHero, removeHero} from "../redux";

let HeroComp = () => {
    let numberOfHeroes = useSelector((state) => state.numberOfHeroes);
    let dispatch = useDispatch();
    return <div>
                <h2>Avenger's Count</h2>
                <h3>Number of Heroes : {numberOfHeroes}</h3>
                <button onClick={() => dispatch(addHero())} >Add Avenger</button>
                <button onClick={() => dispatch(removeHero())} >Remove Avenger</button>
           </div>
}
export default HeroComp


/* 
vijay.shivu@gmail.com
*/