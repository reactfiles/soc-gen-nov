import HeroComp from "./components/hero";
import { Provider } from "react-redux";
import store from "./redux/store";


let App = () => {
    return <div>
                <h2>State Management</h2>
                <Provider store={store}>
                    <HeroComp/>
                </Provider>
           </div>
}
export default App