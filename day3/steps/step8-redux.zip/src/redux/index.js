import {addHero, removeHero} from "./hero/action";

export {
    addHero,
    removeHero
} ;