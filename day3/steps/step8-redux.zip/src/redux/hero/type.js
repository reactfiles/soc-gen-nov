// action type
const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";

export {
    ADD_HERO,
    REMOVE_HERO
}