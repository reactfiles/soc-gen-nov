import React from "react";

let FamilyContext = React.createContext();

// Provider
// Consumer
// let Provider = FamilyContext.Provider;
// let Consumer = FamilyContext.Consumer;
// let SocGenContext = FamilyContext.displayName;

export default FamilyContext;