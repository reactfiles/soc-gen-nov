import GrandParentComp from "./components/grandparent"

let App = () => {
    return <div>
                <h2>State Management</h2>
                <GrandParentComp/>
           </div>
}
export default App