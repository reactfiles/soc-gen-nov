import { useContext } from "react"
import FamilyContext from "../context/familcontext"

let CousinComp = () => {
    let message = useContext(FamilyContext);
    return <div style={ {border : "2px solid grey", padding : "10px" , margin : "10px" , fontFamily: "sans-serif"} }>
                <h2>Cousin Component</h2>
                <h3>Message is { message }</h3>
           </div>
}
export default CousinComp