import { useState } from "react";
// import { Component } from "react";

/* 
class App extends Component{
  state = {power : 0}; 
  // setState()
  render(){
    return <div style={ { border : "2px solid red", padding  : "10px", fontFamily : "sans-serif" } }>
            <h2>App Component</h2>
            <h3> { this.state.power } </h3>
           </div>
  }
} */

// hooks
let App = () => {
    // console.log(useState());
    let [state, setState] = useState(0);
    return <div style={ { border : "2px solid red", padding  : "10px", fontFamily : "sans-serif" } }>
                <h2>App Component</h2>
                <h3>Power is {state}</h3>
                <button onClick={()=> setState(state = state+1)}>Increase Power</button>
            </div>
}

export default App
/* 
forceUpdate
call a function after the state is updated
lifecycle events
higher order components
error handling with lifecycle
*/