import { useState } from "react"
import ChildComp from "./child"

let App = () => {
    let [power, setPower ] = useState(0);
    let [version, setVersion ] = useState(101);
    let [show, setShow ] = useState(true);
    return <div style={ { border : "2px solid red", padding  : "10px", fontFamily : "sans-serif" } }>
                <h2>App Component</h2>
                <input type="range" onChange={(evt)=> setPower(power = Number(evt.target.value) )} />
                <button className="btn btn-primary" onClick={() => setVersion(Math.round(Math.random() * 500))}>Change Version</button>
                <button className="btn btn-primary" onClick={()=> setShow(!show)}>Show / Hide</button>
                { show && <ChildComp power={power} version={version}/> }
           </div>
}

export default App