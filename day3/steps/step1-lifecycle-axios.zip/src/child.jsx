import { Component } from "react";
import axios from "axios";

class Child extends Component{
  state = {
    title : "Child Title",
    asyncData  : {}
  }
  //  Mounted
    // configure your class component with state  
    constructor(){
      super();
     /*  
      this.state = {
          title : "changed from constructor"
      } 
      */
  }
  // Derive the State or a component From Props recieved from parent
  static getDerivedStateFromProps(compProp, compState){
      // console.log(compProp, compState)
      // return true
      return {
          title : compProp.title
      }
  } 
  // when the component is attached to the parent application
  // is used to make async calls
  componentDidMount(){
    axios.get('https://reqres.in/api/users?page=1')
    .then((response) => {
      // handle success
      console.log(response.data);
      this.setState( { asyncData : response.data } )
    })
    .catch(function (error) {
      // handle error
      console.log("Error ",error);
    })
    .finally(function () {
      // always executed
      console.log("promise is now settled");
    });
  }
  // will validate the props recieved from the parent and decide to render or not to render
  shouldComponentUpdate(compProp, compState){
      console.log(compProp, compState);
      if(compProp.power <= 10){
        return true 
      }else{
        return false 
      }
  }
  // will take a backup of the state and the props and store for future use
  getSnapshotBeforeUpdate(){
      return {}
  }
  // when the component has agreed to use the props and re-render the component
  componentDidUpdate(){
      
  }
  // when the component has already removed from its parent
  componentWillUnmount(){
      console.log("child is now unmounted")
  }
  render(){
    console.log("child is rendered",Math.random())
    return <div style={ { border : "2px solid blue", padding  : "10px", fontFamily : "sans-serif" } }>
            <h2>Child Component</h2>
            <h3>{ this.state.title }</h3>
            <h3>Power : { this.props.power }</h3>
            <ol>{this.state.asyncData.data?.map(val => <li key={val.id}>{val.first_name+" "+val.last_name}</li>)}</ol>
          </div>
  }
  clickHandler = () =>{
    
  }
}

export default Child
