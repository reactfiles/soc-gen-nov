import { createRoot } from 'react-dom/client'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <App arg={"main comp's message"} />
)

// app > child > grandchild

/*
Mounted
    constructor()
    static getDerivedStateFromProps() // Derive the State or a component From Props recieved from parent
    render()
    componentDidMount()

Updated
    static getDerivedStateFromProps()
    shouldComponentUpdate()
    render()
    getSnapshotBeforeUpdate()
    componentDidUpdate()

Unmounted
    componentWillUnmount()

Error Handling
    static getDerivedStateFromError()
    componentDidCatch()
*/