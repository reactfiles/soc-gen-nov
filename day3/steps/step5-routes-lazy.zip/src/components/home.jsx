let Home = () => {
    return <div>
                <h2>Home Component</h2>
                <h3>Welcome to Home Page</h3>
           </div>
}

export default Home