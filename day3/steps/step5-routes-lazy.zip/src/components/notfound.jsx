let NotFound = () => {
    return <div>
                <h2>404 : Requested Page Not Found</h2>
                <h3>Please come back later</h3>
           </div>
}

export default NotFound