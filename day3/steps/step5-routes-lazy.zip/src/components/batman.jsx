import { useNavigate, useParams } from "react-router-dom"

let Batman = () => {
    let args = useParams();
    let nav = useNavigate();
    return <div>
                <h2>Batman Component</h2>
                <h3>Welcome to Batman Page</h3>
                <h3>Power : {args.pow}</h3>
                <button onClick={() => nav("/wonderwomen/"+Math.round(Math.random() * 1000))} className="btn btn-primary">Navigate to Wonderwomen</button>
           </div>
}

export default Batman