let Superman = () => {
    return <div>
                <h2>Superman Component</h2>
                <h3>Welcome to Superman Page</h3>
           </div>
}

export default Superman