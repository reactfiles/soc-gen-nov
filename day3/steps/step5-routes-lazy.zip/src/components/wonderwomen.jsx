import { useParams } from "react-router-dom";

let Wonderwomen = () => {
    let args = useParams();
    return <div>
                <h2>Wonder Women Component</h2>
                <h3>Welcome to Wonder women Page</h3>
                <h4>Quantity : { args.power }</h4>
           </div>
}

export default Wonderwomen