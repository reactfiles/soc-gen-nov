let Flash = () => {
    return <div>
                <h2>Flash Component</h2>
                <h3>Welcome to Flash Page</h3>
           </div>
}

export default Flash