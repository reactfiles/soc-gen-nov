import FamilyContext from "../context/familcontext";
import ParentComp from "./parent"
import { useRef, useState } from "react";

let GrandParentComp = () => {
    let [message, setMessage] = useState("default message from grand parent");
    let ipref = useRef();
    let clickHandler = () => {
        setMessage(ipref.current.value)
    }
    return <div style={ {border : "2px solid grey", padding : "10px" , margin : "10px" , fontFamily: "sans-serif"} }>
                <h2>GrandParent Component</h2>
                <h5>Message is {message}</h5>
                <input ref={ipref} type="text" />
                <button onClick={clickHandler}>Change Message</button>
                <hr />
                <FamilyContext.Provider value={message}>
                    <ParentComp/>
                </FamilyContext.Provider>
           </div>
}
export default GrandParentComp